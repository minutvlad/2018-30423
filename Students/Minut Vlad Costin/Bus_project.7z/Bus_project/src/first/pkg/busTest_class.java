package first.pkg;



import static org.junit.Assert.assertEquals;


import org.junit.Test;

public class busTest_class {

	@Test
	public void testDrive() {

		bus  firstBus = new bus ("M", 50, 10);
		firstBus.openDoors();
		
		System.out.println(firstBus.getBrand());
		
	
		assertEquals(firstBus.getNumberOfSeats(), 50);
		
		
		bus  secondBus = new bus ("T");
		secondBus.openDoors();
		secondBus.setNumberOfSeats(20);
		secondBus.setnumber(44);
		System.out.println(secondBus.getBrand());
		
		System.out.println(firstBus.toString());

		//firstBus.sayHello();
		//"I m bus number %s"
	}
}
