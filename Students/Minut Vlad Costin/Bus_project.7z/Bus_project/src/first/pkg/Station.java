package first.pkg;

public class Station {

	private bus[] bus_array;
	private int len;
	
	public void addBus(bus add_bus)
	{
		this.bus_array[len++]=add_bus;
		
	}
	
	
	public Station()
	{
		 this.bus_array = new bus[10];
		 this.len=0;

	}
	
	public bus[] getBusses() {
		return this.bus_array;
	}
	
	public int getNoOfBusses() {
		return this.len;
	}
	
	public String toString() {
		String s= "";
		for(int i=0 ; i<this.len; ++i)
			s+=this.bus_array[i].toString()+' ';
		return s;
	}
}
