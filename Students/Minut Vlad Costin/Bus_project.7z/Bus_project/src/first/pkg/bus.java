package first.pkg;

public class bus {

	private String brand = "M";
	private int numberOfSeats;
	private int number;
	
	//private int[] array; // declaring an array
	//create a new class station, define an atribute of the station being an array of busses as homework:D

	public bus() {

	}

	public bus(String brand) {

		this.brand = brand;

	}

	public bus(String brand, int numberOfSeats, int number) {

		this.brand = brand;
		this.numberOfSeats = numberOfSeats;
		this.number = number;
	}

	public void openDoors() {
		System.out.println("I'm opening my doors");

	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public int getNumberOfSeats() {
		return numberOfSeats;
	}

	public void setNumberOfSeats(int numberOfSeats) {
		this.numberOfSeats = numberOfSeats;
	}
	
	public int getnumber() {
		return number;
	}
	
	public void setnumber (int number)
	{
		this.number = number;
	}

	@Override
	public String toString() {
		return "bus [brand=" + brand + ", numberOfSeats=" + numberOfSeats + ", number=" + number + "]";
	}
	
	
	

}