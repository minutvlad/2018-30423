package first.pkg;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class Station_Test {
	
	@Test
	
	public void testDrive() {
		
		Station firstStation = new Station();
		firstStation.addBus(new bus("C", 90, 2112));
		
		assertEquals(firstStation.getNoOfBusses(), 1);
		assertEquals(firstStation.getBusses()[0].getBrand(), "C");
		
		
		firstStation.addBus(new bus("A", 77, 9908));
		
		assertEquals(firstStation.getNoOfBusses(), 2);
		assertEquals(firstStation.getBusses()[1].getNumberOfSeats(), 77);
		
		
		firstStation.addBus(new bus("O", 75, 3208));
		
		assertEquals(firstStation.getNoOfBusses(), 3);
		assertEquals(firstStation.getBusses()[2].getnumber(), 3208);
		
		System.out.println(firstStation.toString());
	}

}
